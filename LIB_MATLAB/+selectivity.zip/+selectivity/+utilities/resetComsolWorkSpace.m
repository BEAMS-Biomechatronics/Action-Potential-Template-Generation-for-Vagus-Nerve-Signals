clear;
%matlabpool close;
load('comsolDefault.mat');
clc;