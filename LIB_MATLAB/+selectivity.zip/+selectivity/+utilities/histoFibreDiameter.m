classdef histoFibreDiameter < handle
   properties
      distribution;
      fileNameToSaveHisto;
   end
   methods
       function o = histoFibreDiameter(o)
           % default distribution
           o.distribution = [[3 4 5 6 7 8 9 10 11 12 13]*1e-6; 1 3 10 16 23 16 18 8 3 1 1];
           o.fileNameToSaveHisto = 'hFD.mat';
       end
       
       function nRangeArrayNormed = getProportion(o,varargin)
            % getProportion([ fiberDiameter1 fiberDiameter2 fiberDiameter3 ....] )
            % The array must not be sorted before to call this
            % function.
            % 
            % return nRangeArrayNormed = (nInt, 1) with prop of each intervale in the
            % same order than given in the input argument.
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % input management
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            sizeNargin1 = [];
            if nargin == 2
                sizeNargin1 = size(varargin{1});
                if sizeNargin1(1) ~= 1
                    error('histoFibreDiameter:getProportion','Wrong number of input parameters');
                end
            else
                error('histoFibreDiameter:getProportion','Wrong number of input parameters');
            end
           
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%  Input parameter
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            diameterArray = varargin{1};
            % number of fiber diameter in the simulation
            nDiameter = length(diameterArray);
            % Edges of the range for each fibre diameter.. to fill
            % [ limInfD1 limInfD2 limInfD3 ]
            % [ limSupD1 limSupD2 limSupD3 ]
            rangeOfDiameterValidity     = zeros(2,nDiameter);
           
           
                      
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Processing     
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           
            % First sort the diameters by ascending order
            diameterArraySorted                         = sort(diameterArray);
           
           
            % set edges of the diameter range with central value 
            %(or the most available value) = to fiber diameter
            for k = 1:nDiameter
                if k==1
                    rangeOfDiameterValidity(:,1)        = [o.distribution(1,1); (diameterArraySorted(1)+diameterArraySorted(2))/2];
                elseif k==nDiameter
                    rangeOfDiameterValidity(:,nDiameter)      = [(diameterArraySorted(nDiameter-1)+diameterArraySorted(nDiameter))/2; o.distribution(1,end)];
                else
                    rangeOfDiameterValidity(:,k)        = [(diameterArraySorted(k-1)+diameterArraySorted(k))/2; (diameterArraySorted(k)+diameterArraySorted(k+1))/2];
                end
            end

            % range step
            nRangeArraySorted           = [];
            gapRangeDiameterFiber       = o.distribution(1,2)-o.distribution(1,1);
            for k = 1:nDiameter
                  k
                indiceRange             = find(o.distribution(1,:) >=  rangeOfDiameterValidity(1,k)-0.5*gapRangeDiameterFiber & o.distribution(1,:) <=  rangeOfDiameterValidity(2,k)+0.5*gapRangeDiameterFiber);
                propTemp                = ones(size(indiceRange));

                propTemp(1)             = (0.5*gapRangeDiameterFiber+rangeOfDiameterValidity(1,k)-o.distribution(1,indiceRange(1)))/gapRangeDiameterFiber;
                propTemp(end)           = (rangeOfDiameterValidity(2,k)-(o.distribution(1,indiceRange(end))-0.5*gapRangeDiameterFiber))/gapRangeDiameterFiber;
                
                nRange = o.distribution(2,indiceRange)*propTemp';
                nRangeArraySorted = [nRangeArraySorted nRange];
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %% Conditioning of output variable   
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Set the propotion for each range around one fiber diameter
            % value in the same order than the files order (or the same
            % order than the diameterArray order). 
            % Watch out, the loop iterates in the same way than file name
            % LOOP
            nRangeArray = [];
            for k=1:nDiameter
                indInArraySorted    = find(diameterArraySorted == diameterArray(k));
                nRange              = nRangeArraySorted(indInArraySorted);
                nRangeArray         = [nRangeArray nRange];
            end
            nRangeArrayNormed       = nRangeArray/sum(nRangeArray);
            
       end
       function fig = plotHisto(o)

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%          HISTOGRAM of fiber Diameter                   %%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            fig = figure()
            bar(o.distribution(1,:)*1e6,o.distribution(2,:))
            xlabel('Fiber diameter [�m]');
            ylabel('Relative number of fiber in the range');
       end
       
       function saveHisto(o)
           distribution = o.distribution;
           save(o.fileNameToSaveHisto, 'distribution');
       end
       
       function loadHisto(o)
           load(o.fileNameToSaveHisto);
           o.distribution = distribution;
       end
           
   end
end