function [varargout] = detectActivationWithShift(varargin)
%detectActivationWithShift(varargin)
% ('1D') or ('2D')
% 1D and 2D version
% second argument is used to bypass prompter to the user (0 or 1).
% third argument if you want a special distribution to reach the transition
% of the target (cible). Then you must give where the transition occurs in
% percentage of the radius nerve.
    import com.comsol.model.*
    import com.comsol.model.util.*
    import selectivity.comsol.*
    import selectivity.fibreModel.fibre.*
    import selectivity.utilities.*
    import selectivity.anodalBlock.*
    
    warning off MATLAB:MKDIR:DirectoryExists
    
    % ERROR input argument management
    % and 1/2D variable
    dimension = '';
    
    if nargin >= 1
        if strcmp(varargin{1}, '1D') || strcmp(varargin{1}, '2D')
            dimension = varargin{1};
        else
            error('not expected input argument');
        end
    else 
       error('not expected input argument');
    end
    
    
    bypassForce = 0;
    if nargin >= 2 
        bypassForce = varargin{2};
    end

    ciblePosition = [];
    if nargin == 3
        ciblePosition = varargin{3};
    end
    
    % Do not use Local MPI
    distcomp.feature( 'LocalUseMpiexec', false )
    % delete the current parallel task pool if running
    delete(gcp);
    
    
    % random folder to save Data
    folderSaveData = selectivity.utilities.randomString(10);
    
    % The function can return the name of the folder where data has been
    % saved (random folder name). 
    if nargout == 1
        varargout{1} = folderSaveData;
    end
    
    %permet de forcer le recalcul des tensions par FEM, m�me si cela a d�j� �t� fait. (default = 0)
    %La demande est faites par une "boite" de dialogue en d�but d'ex�cution. 
    force = 0;              
    notDecided = 1;
    while notDecided
        if bypassForce == 1
            force       = 0;
            break
        end
        force = input('Do you want to recompute the voltage by FEM even if it has already been done ? [Y/N]','s')
        if force == 'Y'
            force=1;
            notDecided = 0;
        elseif force == 'N'
            force=0;
            notDecided = 0;
        end
    end
    
    
    
    %% PARAMETRES
    % Modification apr�s avoir cr�er les param�tres par d�faut.
    % Pour modifier un param�tre, modifer le fichier parameter.mat, avec la
    % commande suivante : save('parameters.mat', nomVariable, '-append');
    parametersParaboleAnode();
    load parameters
    nNodeShift = nNodeShift;
    
    %% Calcul du courant 'objectif'
    % Calcul du courrant n�cessaire pour activer la fibre de 'fibreSeuil'
    % � la position d�finie dans le fichier de config et bloquer les AP sur les fascicules
    % externes.
    if current1==0
        current1         = findCurrent(fibreDSeuil, positionSeuil, comsolModel);
    end

    
    % making directory if does not exist yet
    mkdir('figure');
    
    % run the parallel process
    parpool('local',nProc);  
    
    % boucle pour la taille de fibre
    for w=1:numel(fiberSize)
        
        % boucle pour le shift
        for n=1:nNodeShift
            

            %% Changement de valeur des param�tres
            fibreD  = fiberSize(w);           %m
            shift   = (n-1)/nNodeShift;
            save('parameters.mat', 'fibreD', 'shift', '-append');
            save('parameters.mat', 'current1', 'fibreDSeuil', '-append');


            

            %% MODELE TENSION COMSOL
            %On donne un nom au fichier comsol qui va contenir les r�sultats de la
            %simulation. De cette fa�on, on n'est pas oblig� de recalculer les tensions
            %pour chaque simulation. Pour forcer le recalcul de ces simulations, on
            %peut mettre � la variable 'force', la valeur true (1).

            filenameVe = sprintf('r1D_%f_r2D_%f_rD_%f_cuffL_%f_alpha_%f_sigmaExt_%f.mph',ring1D*1e3 ,ring2D*1e3 ,ringD*1e3, cuffL*1e3, alphaP, sigmaEXT);
            a=dir('.\COMSOL_VE\');
            b=struct2cell(a);
            fileNameVeDoNotExist = ~any(ismember(b(1,:),filenameVe));

            %premier cas, si on force � recalculer les tensions dans le mod�le FEM du
            %nerf ou que le mod�le n'a pas encore �t� r�solu, le mod�le est charg�, 
            %r�solu, puis sauvegard�. 
            if fileNameVeDoNotExist || force
                %load model

                model   = comsolModel();
               

                %shortcut Model
                study   = model.study('std1');
                data    = model.result.dataset('dset1');

                %running model
                ModelUtil.showProgress(true);
                
                % make subfolder if does not exist and save the model
                mkdir('COMSOL_VE');
                model.save([pwd '\COMSOL_VE\' filenameVe]);
            % sinon, on charge directement le fichier COMSOL contenant d�j� la solution
            % pour avoir acc�s aux valeurs de la tension.
            else
                model   = mphload([pwd '\COMSOL_VE\' filenameVe]);

                %shortcut Model
                study   = model.study('std1');
                data    = model.result.dataset('dset1');

            end



            %% Extraction des tensions externes aux noeuds
            % A refaire pour chaque taille de fibre, et pour chaque shift
            % des noeuds. 
            
            % Le calcul des coordonn�es des noeuds de la fibre d�pend de
            % la taille de la fibre et du shift des noeuds. Il faut donc
            % appeller cette fonction � chaque fois que l'on d�sire changer
            % de taille de fibre ou de shift des noeuds. 
            CoordonneesFibresXYZ = [];
            if strcmp(dimension, '2D')
                CoordonneesFibresXYZ = getFiberCoordinates('2D');
            else
                if isempty(ciblePosition)
                    CoordonneesFibresXYZ = getFiberCoordinates('1D');
                else
                    CoordonneesFibresXYZ = getFiberCoordinates('1D', [], ciblePosition);
                end
            end

            % Extraction de la tension aux coordonn�es des noeuds depuis le
            % mod�le COMSOL. 
            Ve                  = getExternalVoltage(model, CoordonneesFibresXYZ);
            

            %% MODELE FIBRE MATLAB
        
            
            % finding number of fascicles and number of fibers by fascicles.
            sizeXYZ                 = size(CoordonneesFibresXYZ);
            
            nFibre                  = sizeXYZ(2);
            nNoeuds                 = sizeXYZ(3);
            
            % tableau pour sauvegarder le type. 
            % peut-�tre � faire apr�s sur les donn�es. 
            type                         = [];
            Vm                           = cell(1,nFibre);
            time                         = cell(1,nFibre);
            fibreSave                    = cell(1,nFibre);
            

            %boucle fibres dans fascicules
            for m = 1:1
                
                % save the type for the actual fiber
                typeTemp            = zeros(1,nFibre); 
                
                
                % making an array with waveform object for shared parallel
                % computing. (array of copy)                
                WF1Array(1:nFibre)          = WF1.copy();
                WF2Array(1:nFibre)          = WF2.copy();
                
                TCArray(1:nFibre)           = TC;
                nNoeudsArray(1:nFibre)      = nNoeuds;
                fibreDArray(1:nFibre)       = fibreD;
                current1Array(1:nFibre)     = current1;
                current2Array(1:nFibre)     = current2;
                
                
                % same for solution to save
                VmTemp                      = cell(1,nFibre);
                timeTemp                    = cell(1,nFibre);
                fibreSaveTemp               = cell(1,nFibre);
                recordFigArray              = zeros(1,nFibre);
                recordFigArray(1:nFibre)    = recordFig;
                
                % Ve(nFascicle, nFibre, nNoeuds) -> Vek(nFibre, nNoeuds)
                Vek                 = squeeze(Ve(:,:));
                
                              
                
                parfor k=1:nFibre
                    
                    % In the 1D case, if the z coordinates of first node fiber
                    % is equal to zero, this fiber must not be solved.
                    firstZCoordinates = squeeze(CoordonneesFibresXYZ(3, k, 1));
                    boolFiberNotToCompute = firstZCoordinates == 0;
                    

                    fibreInstance = fibre(fibreDArray(k), nNoeudsArray(k), TCArray(k), WF1Array(k), WF2Array(k));
                    
                    % Extraction de la tension externe dans le tableau Vek
                    VeFibre         = Vek(k,:);
                    
                    %Introduction des valeurs de Ve aux noeuds dans le
                    %mod�le de la fibre. 
                    if strcmp(dimension, '2D') || (strcmp(dimension, '1D') && ~boolFiberNotToCompute)
                        
                        fibreInstance       = fibreInstance.setVe(VeFibre);
                        fibreInstance       = fibreInstance.setCurrent([current1Array(k) current2Array(k)]);

                        %R�solution du probl�me d'une fibre soumise � un potentiel Ve
                        %aux noeuds. 
                        fibreInstance       = fibreInstance.solve();
                        
                        % Save some data (Vm and time)
                        VmTemp{k}           = squeeze(fibreInstance.solution(:,1:fibreInstance.n));
                        timeTemp{k}         = fibreInstance.time;
                        fibreSaveTemp{k}    = fibreInstance;

                        %Analyse de la propagation des AP et classification de la fibre dans l'une des 4 cat�gories.            
                        APtracking          = AP();
                        APtracking          = APtracking.findAP(fibreInstance.solution(:,1:fibreInstance.n), fibreInstance.time, fibreInstance.Ve', fibreInstance.WF1.TPulseGlobal);
                        
                        %Sauvegarde
                        typeTemp(k)         = APtracking.type;

                        % enregistrement des figures
                        if recordFigArray(k)
                        
                            %Mise en forme du r�sultat pour la fibre
                            fig                 = fibreInstance.plotBaton(15,APtracking);


                            figureFileName      = sprintf('fibreNum_%f',k);
                            figureFileName      = strrep(figureFileName, '.', '_');
                            saveas(fig, ['./figure/' figureFileName '.fig']);

                           
                        end
                        
                        %progression variable
                        progresssionNerf    = k/(nFibre);
                        progressionShift    = n/nNodeShift;
                        
                        % progression display
                        display(sprintf('Taille fibre progression (level 1) : %d/3',w));
                        display(sprintf('Progression shift (level 2) : %0.2f %%',progressionShift*100));
                        
                        display(sprintf('Progression nerf (level 3) : %0.2f %%',progresssionNerf*100));
                        
                    else
                        typeTemp(k)         = -5;
                    end

                end
                
                display('==================================')
                % record Vm, time, and type in cell array         
                type = [type typeTemp];
                Vm(:)                                   = VmTemp;
                time(:)                                 = timeTemp;
                fibreSave(:)                            = fibreSaveTemp;
                
            end
           
           
            
            
            filename                                = ['shift_' num2str(shift) '.mat'];
            filename                                = strrep(filename, '.', '_');
            
            if recordVm
                save(filename, 'Vm', 'type', 'time', 'CoordonneesFibresXYZ', 'fibreSave');
            else
                save(filename, 'type', 'CoordonneesFibresXYZ');
            end
            saveData(folderSaveData);
            % making directory if does not exist yet
            mkdir('figure');
        end
        
    end
    
    % stop the parallel process
    delete(gcp);
    
end
